function uno(){
    console.log("Mesa 1");
}

function dos(){
    console.log("Mesa 2");
}

function tres(){
    console.log("Mesa 3");
}

function cuatro(){
    console.log("Mesa 4");
}

function cinco(){
    console.log("Mesa 5");
}

function seis(){
    console.log("Mesa 6");
}

function siete(){
    console.log("Mesa 7");
}

function ocho(){
    console.log("Mesa 8");
}

function nueve(){
    console.log("Mesa 9");
}

function diez(){
    console.log("Mesa 10");
}